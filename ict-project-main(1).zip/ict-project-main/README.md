# ict-project
puolustusvoimien ict-varusmies koe
